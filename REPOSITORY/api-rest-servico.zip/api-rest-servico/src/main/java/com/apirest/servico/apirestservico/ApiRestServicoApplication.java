package com.apirest.servico.apirestservico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestServicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestServicoApplication.class, args);
	}

}
